package com.example.vini.sistemadecompartilhamento.BDHelper;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;

import com.example.vini.sistemadecompartilhamento.model.Cadastros;


public class CadastroBd  extends SQLiteOpenHelper {

    private static final String DATABASE = "bdcadastros";
    private static final int VERSION = 1;


    public CadastroBd(Context context) {
        super(context, DATABASE, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String cadastro = "CREATE TABLE cadastros(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,campus VARCHAR(50) NOT NULL, email VARCHAR(50) NOT NULL, senha VARCHAR(100) NOT NULL )";
        db.execSQL(cadastro);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String cadastro = "DROP TABLE IF EXISTS produtos";
        db.execSQL(cadastro);


    }




    public void salvardados(Cadastros cadastro) {


        ContentValues values = new ContentValues();

        values.put("campus", cadastro.getNomeCadastrado());
        values.put("email", cadastro.getEmailCadastrado());
        values.put("senha", cadastro.getSenhaCadastrada());


        getWritableDatabase().insert("cadastros", null, values);
    }



        public int verificar(String EmailS, String SenhaS, String Campus) {

        String loginDB, senhaDB, campusDB;
        int total, i, j;
        j =  0;


        Cursor c = getReadableDatabase().query("cadastros", new String[]{"id","campus", "email", "senha"}, null, null, null, null, null, null);

        total = c.getCount();



        if (total > 0) {
            c.moveToFirst();
            i = 1;
            while (i < total) {
                campusDB = c.getString(1);
                loginDB = c.getString(2);
                senhaDB = c.getString(3);

                i++;

                if (EmailS.equals(loginDB) && SenhaS.equals(senhaDB)&& Campus.equals(campusDB)) {

                    j++;




                }
                else {




                    return j;
                }



            }

            c.close();

        }

            return j;
        }
}
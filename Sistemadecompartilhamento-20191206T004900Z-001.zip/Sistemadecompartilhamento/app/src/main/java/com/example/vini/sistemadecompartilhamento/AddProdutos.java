package com.example.vini.sistemadecompartilhamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.vini.sistemadecompartilhamento.BDHelper.ProdutosBd;
import com.example.vini.sistemadecompartilhamento.model.Produtos;

public class AddProdutos extends AppCompatActivity {

    EditText etNomeItem, etObservacao, etNumero;
    Button btVoltar, btEnviar;
    Produtos EditarProduto, produto;
    ProdutosBd bdHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activityaddprodutos);

            produto = new Produtos();
            bdHelper = new ProdutosBd(AddProdutos.this );

            Intent intent= getIntent();
            EditarProduto = (Produtos) intent.getSerializableExtra("produto-escolhido");

        etNomeItem = findViewById(R.id.etNomeItem);
        etNumero = findViewById(R.id.etNumero);
        etObservacao = findViewById(R.id.etObservacao);
        btEnviar = findViewById(R.id.btEnviar);
        btVoltar = findViewById(R.id.btVoltar);

        if (EditarProduto !=null){
            btEnviar.setText("Modificar");
            etNomeItem.setText(EditarProduto.getNomeProduto());
            etObservacao.setText(EditarProduto.getDescricao());
            etNumero.setText(EditarProduto.getQuantidade()+"");

            produto.setId(EditarProduto.getId());
        }
        else{
            btEnviar.setText("Cadastrar");
        }

    btEnviar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
    produto.setNomeProduto(etNomeItem.getText().toString());
    produto.setDescricao(etObservacao.getText().toString());
    produto.setQuantidade(Integer.parseInt(etNumero.getText().toString()));


        if(btEnviar.getText().toString().equals("Cadastrar")){
    bdHelper.salvarProduto(produto);
    bdHelper.close();

        }
        else{
            bdHelper.alterarProduto(produto);
            bdHelper.close();
        }
        }
    });

    }






    public void onClickVoltar(View v) {

        Intent mudarTela = new Intent();
        mudarTela.setClass(AddProdutos.this, Inventario.class);
        startActivity(mudarTela);
        finish();


    }

public void onClickEnviar(View v) {



}

}

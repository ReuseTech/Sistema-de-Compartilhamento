package com.example.vini.sistemadecompartilhamento;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.vini.sistemadecompartilhamento.BDHelper.CadastroBd;
import com.example.vini.sistemadecompartilhamento.BDHelper.ProdutosBd;
import com.example.vini.sistemadecompartilhamento.model.Cadastros;

public class MainActivity extends AppCompatActivity {

    EditText etEmail, etCampus;
    EditText etSenha;
    Button Login;
    CadastroBd bdHelper;
    int j;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = findViewById(R.id.etEmail);
        etSenha = findViewById(R.id.etSenha);
        Login = findViewById(R.id.Login);
        etCampus = findViewById(R.id.etCampus);

bdHelper = new CadastroBd(this);
    }

    public void onClickLogin(View v) {


       String EmailS = etEmail.getText().toString();
        String SenhaS = etSenha.getText().toString();
        String Campus = etCampus.getText().toString();


        if (Campus.equals("Admin") && EmailS.equals("Admin")&& SenhaS.equals("senhaerrada")){

            Intent mudarTela = new Intent();
            mudarTela.setClass(MainActivity.this, MenuADM.class);
            startActivity(mudarTela);
            finish();
        }

        if (Campus.equals("Brusque") && EmailS.equals("reusetech.ifc@gmail.com")&& SenhaS.equals("123mudar")){

            Intent mudarTela = new Intent();
            mudarTela.setClass(MainActivity.this, MenuInicial.class);
            startActivity(mudarTela);
            finish();
        }

j = bdHelper.verificar(EmailS, SenhaS, Campus);




        {

            if (j>=1 && Campus.equals("Brusque")){

                Intent mudarTela = new Intent();
                mudarTela.setClass(MainActivity.this, MenuInicial.class);
                startActivity(mudarTela);
                finish();
            }


        }









    }
}



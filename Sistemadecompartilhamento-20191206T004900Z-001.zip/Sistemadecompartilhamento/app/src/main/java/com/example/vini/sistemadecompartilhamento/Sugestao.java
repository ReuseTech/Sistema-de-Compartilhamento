package com.example.vini.sistemadecompartilhamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Sugestao extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sugestao);





    }

    public void onClickVoltar(View v) {

        Intent mudarTela = new Intent();
        mudarTela.setClass(Sugestao.this, MenuInicial.class);
        startActivity(mudarTela);
        finish();


    }
}

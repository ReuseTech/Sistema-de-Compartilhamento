package com.example.vini.sistemadecompartilhamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.vini.sistemadecompartilhamento.BDHelper.CadastroBd;
import com.example.vini.sistemadecompartilhamento.BDHelper.ProdutosBd;
import com.example.vini.sistemadecompartilhamento.model.Cadastros;
import com.example.vini.sistemadecompartilhamento.model.Produtos;

public class AddUsuarios extends AppCompatActivity {

    EditText etEmail;
    EditText etSenha;
    EditText etNome;
    CadastroBd bdHelper;
    Cadastros cadastro;
    Button btCadastrar, btVoltar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_usuarios);

        etEmail = findViewById(R.id.etEmail);
        etSenha = findViewById(R.id.etSenha);
        btCadastrar = findViewById(R.id.btCadastar);
        btVoltar = findViewById(R.id.btVoltar);





        cadastro = new Cadastros();
        bdHelper = new CadastroBd(AddUsuarios.this );



    }




public void onClickVoltar(View v){

    Intent mudarTela = new Intent();
    mudarTela.setClass(AddUsuarios.this, MenuADM.class);
    startActivity(mudarTela);
    finish();

}

public void onClickCadastrar(View v){
    String email = etEmail.getText().toString();
    String senha = etSenha.getText().toString();
    String campus = etNome.getText().toString();



    if (campus.isEmpty() || email.isEmpty() || senha.isEmpty()){

        Toast.makeText(getApplicationContext(), "Todos os campos devem ser preenchidos", Toast.LENGTH_LONG).show();



    }
    else {

        bdHelper.salvardados(cadastro);
        bdHelper.close();



       Intent mudarTela = new Intent();
        mudarTela.setClass(AddUsuarios.this, MenuADM.class);
        startActivity(mudarTela);
        finish();


    }
}


}
package com.example.vini.sistemadecompartilhamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MenuADM extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_adm);
    }


public void onClickCadastrar(View v){
    Intent mudarTela = new Intent();
    mudarTela.setClass(MenuADM.this, AddUsuarios.class);
    startActivity(mudarTela);
    finish();

}


public  void OnclickVoltar  (View v){

    Intent mudarTela = new Intent();
    mudarTela.setClass(MenuADM.this, MainActivity.class);
    startActivity(mudarTela);
    finish();

}
}
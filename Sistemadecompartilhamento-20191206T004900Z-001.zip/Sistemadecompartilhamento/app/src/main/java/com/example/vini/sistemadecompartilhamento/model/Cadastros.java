package com.example.vini.sistemadecompartilhamento.model;

import android.database.Cursor;

public class Cadastros {


    private Long id;
    private String emailCadastrado;
    private String senhaCadastrada;
    private String nomeCadastrado;

    public String getNomeCadastrado() {
        return nomeCadastrado;
    }

    public void setNomeCadastrado(String nomeCadastrado) {

        this.nomeCadastrado = nomeCadastrado;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmailCadastrado() {
        return emailCadastrado;
    }

    public void setEmailCadastrado(String emailCadastrado) {
        this.emailCadastrado = emailCadastrado;
    }

    public String getSenhaCadastrada() {
        return senhaCadastrada;
    }

    public void setSenhaCadastrada(String senhaCadastrada) {
        this.senhaCadastrada = senhaCadastrada;
    }


}



package com.example.vini.sistemadecompartilhamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuInicial extends AppCompatActivity {

    Button button4,button7,button8;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_inicial);

        button4 = findViewById(R.id.button4);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
    }


    public void onClicklicinventorio (View v) {

        Intent mudarTela = new Intent();
        mudarTela.setClass(MenuInicial.this, Inventario.class);
        startActivity(mudarTela);
        finish();


    }

    public void onClicklicsolicitacao (View v) {

        Intent mudarTela = new Intent();
        mudarTela.setClass(MenuInicial.this, Solicitacao.class);
        startActivity(mudarTela);
        finish();


    }

    public void onClicklicsugestao (View v) {

        Intent mudarTela = new Intent();
        mudarTela.setClass(MenuInicial.this, Sugestao.class);
        startActivity(mudarTela);
        finish();


    }

}
